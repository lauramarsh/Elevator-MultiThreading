
public class SimClock
{
	public static int counter;
	
	public SimClock()
	{
		counter = 0;
	}
	
	public static void tick()
	{
		++counter;
	}
	
	public static int getTime()
	{
		return counter;
	}
}
