
public class BuildingManager
{
	private BuildingFloor[] floors;
	
	
	public BuildingManager()
	{
		floors = new BuildingFloor[5];
	}
	
	public synchronized BuildingFloor[] getBuildingFloors()
	{
		return floors;
	}
}
