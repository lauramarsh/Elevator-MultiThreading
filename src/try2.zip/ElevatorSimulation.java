import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class ElevatorSimulation
{
	//builds elevator threads
	//builds the building manager
	//creates an arraylist[arraylist] of passengerarrivals object for all 5 floors
	//to keep track of behavior during simulation
	private int simLength;
	private int simSecond;
	private ArrayList<ArrayList<PassengerArrival>> pb = new ArrayList<ArrayList<PassengerArrival>>();
	// pb = passenger behavior
	
	
	public void start()
	{
		readText();
	}
	
	public void printBuildingState()
	{
//		//for each floor:
//			all passengers requesting access on the floor
//			total # of passengers who exited an elevator on the floor
//			current number of passengers waiting for an elevator
//			elevator currently going to floor
//		//for each elevator:
//			total # of passengers that entered the elevator (TOOOTAL)
//			total # of passengers that exited this elevator (on each specific floor)
//			current # of passengers heading to ANY floor
		
		
	}
	
	public void readText()
	{
		Scanner inFile = null;
		int floorCount = 0;
		try
		{
			inFile = new Scanner(new File("ElevatorConfig.txt"));
			String Line;
			simLength = inFile.nextInt();
			simSecond = inFile.nextInt();
			inFile.nextLine(); //advances that one extra token that was missed
			
			while (inFile.hasNextLine())
			{
				
				Line = inFile.nextLine();
				String[] tokens = Line.split(";");
				ArrayList<PassengerArrival> innerList = new ArrayList<PassengerArrival>();
				
				for (int i = 0; i< tokens.length; i++)
				{
					String[] innerTokens = tokens[i].split(" ");
					PassengerArrival PA = new PassengerArrival(innerTokens[0], innerTokens[1], innerTokens[2]);
					innerList.add(PA);
				}
				pb.add(innerList);
				floorCount++;
				
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		
	}
}
