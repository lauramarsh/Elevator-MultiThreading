import java.util.ArrayList;

public class Elevator
{
	private int elevatorID;
	private int currentFloor;
	private int numPassengers;
	private int totalLoadedPassengers;
	private int totalUnloadedPassengers;
	private ArrayList<ElevatorEvent> moveQueue = new ArrayList<ElevatorEvent>();
	private int[] passengerDestinations;
	private BuildingManager manager;
	
	public void setElevatorID(int ID)
	{
		elevatorID = ID;
	}
	
	public void setCurrentFloor(int floor)
	{
		currentFloor = floor;
	}
	
	public void setNumPassengers(int passengers)
	{
		numPassengers = passengers;
	}
	
	public void setLoadedPassengers(int loaded)
	{
		numPassengers = loaded;
	}
	
	public void setUnloadedPassengers(int unloaded)
	{
		numPassengers = unloaded;
	}
	
	public int getElevatorID()
	{
		return elevatorID;
	}
	
	public int getCurrentFloor()
	{
		return currentFloor;
	}
	
	public int getNumPassengers()
	{
		return numPassengers;
	}
	
	public int getLoadedPassengers()
	{
		return totalLoadedPassengers;
	}
	
	public int getUnloadedPassengers()
	{
		return totalUnloadedPassengers;
	}
	
	public ArrayList<ElevatorEvent> getMoveQueue()
	{
		return moveQueue;
	}
	
	public int[] getPassengerDestinations()
	{
		return passengerDestinations;
	}
	
	public BuildingManager getManager()
	{
		return manager;
	}
	
	public Elevator(){}
	
	public Elevator(int ID, BuildingManager bm)
	{
		elevatorID = ID;
		manager = bm;
	}
	
	public void run()
	{
		
	}
	
}
