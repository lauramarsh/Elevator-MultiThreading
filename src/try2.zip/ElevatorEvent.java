
public class ElevatorEvent
{
	private int destination;
	private int expectedArrival;
	
	public void setDestination(int dest)
	{
		destination = dest;
	}
	
	public int getDestination()
	{
		return destination;
	}
	
	public double getExpectedArrival()
	{
		return expectedArrival;
	}
	
	public void setExpectedArrival(int FloorDifference)
	{
		expectedArrival = FloorDifference*5 + 20;
	}
}
