
public class PassengerArrival
{
	private int numPassengers;
	private int destinationFloor;
	private int timePeriod;
	private int expectedTimeOfArrival;
	
	public PassengerArrival(String nP, String dF, String tP)
	{
		numPassengers = Integer.parseInt(nP);
		destinationFloor = Integer.parseInt(dF);
		timePeriod = Integer.parseInt(tP);
		expectedTimeOfArrival = timePeriod;
	}
	
//	public void setNumPassenger(int passenger)
//	{
//		numPassengers = passenger;
//	}
//	
//	public void setDestinationFloor(int destination)
//	{
//		destinationFloor = destination;
//	}
//	
//	public void setTimePeriod(int time)
//	{
//		timePeriod = time;
//	}
	
	public void setExpectedTimeOfArrival()
	{
		expectedTimeOfArrival += timePeriod;
	}
		
	public int getNumPassengers()
	{
		return numPassengers;
	}
	
	public int getDestinationFloor()
	{
		return destinationFloor;
	}
	
	public int getTimePeriod()
	{
		return timePeriod;
	}
	
	public int getExpectedTimeOfArrival()
	{
		return expectedTimeOfArrival;
	}
}
