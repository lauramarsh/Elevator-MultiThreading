//Lab4 main class
//Partner1: Laura Marsh
//		ID: 28787340
//Partner2: Carl Altoveros 
//		ID: 31815680

public class lab4
{
	public static void main(String[] args)
	{
		ElevatorSimulation ES = new ElevatorSimulation();
		ES.start();
	}
}