import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ElevatorSimulation extends Thread
{
	private int simLength;
	private int simSecond;
	private ArrayList<ArrayList<PassengerArrival>> pB = new ArrayList<ArrayList<PassengerArrival>>();
	
	
	public void start()
	{
		BuildingManager BM = new BuildingManager();
		readText();
		
		Elevator E0 = new Elevator(0, BM); //RUNNABLE
		Elevator E1 = new Elevator(1, BM);
		Elevator E2 = new Elevator(2, BM);
		Elevator E3 = new Elevator(3, BM);
		Elevator E4 = new Elevator(4, BM);
		
		Thread t1 = new Thread(E0);
		Thread t2 = new Thread(E1);
		Thread t3 = new Thread(E2);
		Thread t4 = new Thread(E3);
		Thread t5 = new Thread(E4);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		while (SimClock.getTime() <= simLength)
		{
			for (int i = 0; i < pB.size(); ++i)
			{
				for (int j = 0; j < pB.get(i).size(); ++j)
				{
					if (SimClock.getTime() == pB.get(i).get(j).getExpectedTimeOfArrival())
					{
						BM.setArrival(i, pB.get(i).get(j).getDestinationFloor(), pB.get(i).get(j).getNumPassengers());
						pB.get(i).get(j).setExpectedTimeOfArrival();
					}
				}
			}
			try
			{
				Thread.sleep(simSecond);
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
			SimClock.tick();
		}
		
		t1.interrupt();
		t2.interrupt();
		t3.interrupt();
		t4.interrupt();
		t5.interrupt();
	}
	
	public void printBuildingState()
	{
		System.out.println("----- FINAL BUILDING STATE -----");
		//EVERY PICK UP/DROP OFF, EVERY PASSENGER/ELEVATOR ARRIVAL
//		//for each floor:
//			all passengers requesting access on the floor
//			total # of passengers who exited an elevator on the floor
//			current number of passengers waiting for an elevator
//			elevator currently going to floor
//		//for each elevator:
//			total # of passengers that entered the elevator (TOOOTAL)
//			total # of passengers that exited this elevator (on each specific floor)
//			current # of passengers heading to ANY floor
		
		
	}
	
	public void readText()
	{
		Scanner inFile = null;
		ArrayList<ArrayList<PassengerArrival>> passBehav = new ArrayList<ArrayList<PassengerArrival>>();

		try
		{
			inFile = new Scanner(new File("ElevatorConfig.txt"));
			String Line;
			simLength = inFile.nextInt();
			simSecond = inFile.nextInt();
			inFile.nextLine(); //advances that one extra token that was missed
			
			while (inFile.hasNextLine())
			{
				ArrayList<PassengerArrival> currentFloorBehavior = new ArrayList<PassengerArrival>();
				Line = inFile.nextLine();
				String[] tokens = Line.split(";");
				
				for (int i = 0; i< tokens.length; i++)
				{
					String[] innerTokens = tokens[i].split(" ");
					PassengerArrival PA = new PassengerArrival(innerTokens[0], innerTokens[1], innerTokens[2]);
					currentFloorBehavior.add(PA);
				}
				passBehav.add(currentFloorBehavior);
			}
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		pB = passBehav;
	}
}