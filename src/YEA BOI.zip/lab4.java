public class lab4
{
	public static void main(String[] args)
	{
		ElevatorSimulation ES = new ElevatorSimulation();
		ES.start();
	}
}