public class SimClock
{
	private static int counter = 0;
	
	public static void tick()
	{
		++counter;
	}
	
	public static int getTime()
	{
		return counter;
	}
}
